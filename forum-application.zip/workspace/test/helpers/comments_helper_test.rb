require 'test_helper'

class CommentsHelperTest < ActionView::TestCase
end
